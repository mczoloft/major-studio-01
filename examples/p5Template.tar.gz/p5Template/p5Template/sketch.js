function setup() {
    createCanvas(windowWidth, windowHeight);
}

function draw() {
    rect(mouseX, mouseY, 10, 10);
}